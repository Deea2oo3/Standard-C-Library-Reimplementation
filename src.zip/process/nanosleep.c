#include <time.h>
#include <unistd.h>
#include <internal/syscall.h>
#include <errno.h>

int nanosleep(const struct timespec *x, struct timespec *y) {
    int ret = syscall(__NR_nanosleep, x, y);
    if (ret < 0) {
        errno = -ret;
        return -1;
    }
    return 0;
}
