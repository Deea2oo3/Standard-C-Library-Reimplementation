#include <time.h>
#include <unistd.h>
#include <internal/syscall.h>
#include <errno.h>

// Implementam functia sleep folosind functia nanosleep
unsigned int sleep(unsigned int seconds){
    struct timespec x, y;
    x.sec = seconds;
    x.nano_sec = 0;
    while (nanosleep(&x, &y) == -1) {
        if (errno == EINTR) {
            x = y;
        } else {
            return (unsigned int) x.sec;
        }
    }
    return 0;
}
