// SPDX-License-Identifier: BSD-3-Clause

#include <internal/mm/mem_list.h>
#include <internal/types.h>
#include <internal/essentials.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stddef.h>

void *malloc(size_t size)
{
    // Alocam memorie folosind mmap
	void *ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    // Verificam daca memoria a fost alocata
    if (ptr == MAP_FAILED) {
        return NULL;
    }
    // Adaugam blocul in lista
    if (mem_list_add(ptr, size) != 0) {
        munmap(ptr, size);
        return NULL;
    }
    return ptr;
}

void *calloc(size_t nmemb, size_t size)
{
    // Calculam cat spatiu este necesar alocarii
	size_t total = nmemb*size;
    // Alocam memorie folosind mmap
    void *ptr = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    // Verificam daca memoria a fost alocata
    if (ptr == MAP_FAILED) {
        errno = ENOMEM;
        return NULL;
    }
    // Adaugam blocul in lista
    if (mem_list_add(ptr, total) != 0) {
        munmap(ptr, total);
        return NULL;
    }
    memset(ptr, 0, total);
    return ptr;
}

void free(void *ptr)
{
    // Cautam blocul de memorie pe care vrem sa-l eliberam
	struct mem_list *block = mem_list_find(ptr);
    // Verificam daca am gasit blocul de memorie
    if (block != NULL) {
        size_t size = block->len;
        // Stergem blocul de memorie
        if (mem_list_del(ptr) == 0)
        {
            munmap(ptr, size);
        }
    }
}

void *realloc(void *ptr, size_t size)
{
    // Daca ponterul este NULL alocam memorie folosind malloc
	if (ptr == NULL) {
        return malloc(size);
    }
    // Cautam blocul de memorie asociat pointerului
    struct mem_list *block = mem_list_find(ptr);
    // Verificam daca am gasit blocul de memorie
    if (block == NULL) {
        errno = EINVAL;
        return NULL;
    }
    // Realocam memorie folosind mremap
    void *ptr_2 = mremap(ptr, block->len, size, 0);
    if (ptr_2 == MAP_FAILED) {
        ptr_2 = malloc(size);
        if (ptr_2 != NULL) {
            free(ptr);
            return ptr_2;
        }
    } else {
        // Actualizam lungimea blocului de memorie
        block->len = size;
    }
    return ptr_2;
}

void *reallocarray(void *ptr, size_t nmemb, size_t size)
{
    // Suntem atenti la overflow
	if (nmemb > 0 && SIZE_MAX/nmemb < size) {
        errno = ENOMEM;
        return NULL;
    }
    // Calculam dimensiunea necesara pentru realocare
    size_t total = nmemb*size;
    // Realocam memorie cu ajutorul functiei realloc
    return realloc(ptr, total);
}
