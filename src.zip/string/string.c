// SPDX-License-Identifier: BSD-3-Clause

#include <string.h>

// Copiem sirul source in sirul destination
char *strcpy(char *destination, const char *source)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	size_t i = 0;
	while (*(source + i) != '\0') {
		*(destination + i) = *(source + i);
		i++;
	}
	*(destination + i) = '\0';
	return destination;
}

// Copiem len caractere din sirul source in sirul destination
char *strncpy(char *destination, const char *source, size_t len)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	size_t i = 0;
	while (*(source + i) != '\0' && i < len) {
		*(destination + i) = *(source + i);
		i++;
	}
	// Daca s-a terminat sirul source, dar mai avem caractere de copiat
	// vom pune caracterul '\0' pe restul pozitiilor
	for (; i < len; i++) {
		*(destination + i) = '\0';
	}
	return destination;
}

// La sirul destination alipim sirul source
char *strcat(char *destination, const char *source)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	char *new_string = destination;
	while (*new_string != '\0') {
		new_string++;
	}
	strcpy(new_string, source);
	return destination;
}

// La sirul destination alipim len caractere din sirul source
char *strncat(char *destination, const char *source, size_t len)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	size_t dest_len = strlen(destination);
    size_t i = 0;
	for (i = 0 ; i < len && *(source + i) != '\0' ; i++) {
        *(destination + dest_len + i) = *(source + i);
	}
    *(destination + dest_len + i) = '\0';
	return destination;
}

// Comparam daca doua siruri sunt identice si returnam dupa caz:
// 0 daca sunt identice
// -1 daca primul sir este mai ,,mic" decat cel de-al doilea sir
// 1 daca primul sir este mai ,,mare" decat cel de-al doilea sir
int strcmp(const char *str1, const char *str2)
{
	if (str1 == NULL || str2 == NULL) {
		return 0;
	}
	size_t i = 0;
	while (*(str1 + i) != '\0' && *(str2 + i) != '\0') {
		if (*(str1 + i) < *(str2 + i)) {
			return -1;
		} else if (*(str1 + i) > *(str2 + i)) {
			return 1;
		}
		i++;
	}
	if (*(str2 + i) != '\0') {
			return -1;
		} else if (*(str1 + i) != '\0') {
			return 1;
		}
	return 0;
}

// Comparam daca primele len caractere din doua siruri sunt identice
int strncmp(const char *str1, const char *str2, size_t len)
{
	if (str1 == NULL || str2 == NULL) {
		return 0;
	}
	size_t i = 0;
	while (*(str1 + i) != '\0' && *(str2 + i) != '\0' && i < len) {
		if (*(str1 + i) < *(str2 + i)) {
			return -1;
		} else if (*(str1 + i) > *(str2 + i)) {
			return 1;
		}
		i++;
	}
	return 0;
}

size_t strlen(const char *str)
{
	size_t i = 0;

	for (; *str != '\0'; str++, i++)
		;

	return i;
}

// Cautam prima aparitie a caracterului c de la stanga
// la dreapta in sirul str
char *strchr(const char *str, int c)
{
	if (str == NULL) {
		return NULL;
	}
	size_t i = 0;
	while (*(str + i) != '\0') {
		if (*(str + i) == c) {
			return (char *)(str + i);
		}
		i++;
	}
	return NULL;
}

// Cautam prima aparitie a caracterului c de la dreapta
// la stanga in sirul str
char *strrchr(const char *str, int c)
{
	if (str == NULL) {
		return NULL;
	}
	size_t i = strlen(str);
	while (i > 0) {
		if (*(str + i) == c) {
			return (char *)(str + i);
		}
		i--;
	}
	if (*(str + i) == c) {
		return (char *)(str + i);
	}
	return NULL;
}

// Cautam prima aparitie a subsirului needle de la stanga
// la dreapta in sirul haystack
char *strstr(const char *haystack, const char *needle)
{
	if (haystack == NULL || needle == NULL) {
		return NULL;
	}
	size_t i = 0;
	while (*(haystack + i) != '\0') {
		const char *copy_haystack = haystack + i;
		const char *copy_needle = needle;
		while (*copy_haystack == *copy_needle && *copy_needle != '\0') {
			copy_haystack++;
			copy_needle++;
		}
		if (*copy_needle == '\0') {
			return (char *)(haystack + i);
		}
		i++;
	}
	return NULL;
}

// Cautam prima aparitie a subsirului needle de la dreapta
// la stanga in sirul haystack
char *strrstr(const char *haystack, const char *needle)
{
	if (haystack == NULL || needle == NULL) {
		return NULL;
	}
	size_t i = strlen(haystack);
	while (i > 0) {
		const char *copy_haystack = haystack + i;
		const char *copy_needle = needle;
		while (*copy_haystack == *copy_needle && *copy_needle != '\0') {
			copy_haystack++;
			copy_needle++;
		}
		if (*copy_needle == '\0') {
			return (char *)(haystack + i);
		}
		i--;
	}
	return NULL;
}

// Compiem num octeti de la sursa la destinatie
void *memcpy(void *destination, const void *source, size_t num)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	char *dest = (char *)destination;
	const char *src = (const char *)source;
	size_t i = 0;
	for (i = 0; i < num; i++) {
		*(dest + i) = *(src + i);
	}
	return destination;
}

// Mutam num octeti din sursa in destinatie
void *memmove(void *destination, const void *source, size_t num)
{
	if (destination == NULL || source == NULL) {
		return NULL;
	}
	char *dest = (char *)destination;
	const char *src = (const char *)source;
	size_t i = 0;
	// Luam doua cazuri pentru a avea grija ca cele doua zone sa
	// nu se suprapuna
	if (dest < src) {
		for (i = 0; i < num; i++) {
			*(dest + i) = *(src + i);
		}
	} else { if (dest > src) {
			for (i = num ; i > 0; i--) {
				*(dest + i - 1) = *(src + i - 1);
			}
		}
	}
	return destination;
}

// Comparam continutul(num octeti) intre doua blocuri de memorie
int memcmp(const void *ptr1, const void *ptr2, size_t num)
{
	const char *str1 = (const char *)ptr1;
	const char *str2 = (const char *)ptr2;
	size_t i = 0;
	while (i < num) {
		if (*(str1 + i) < *(str2 + i)) {
			return -1;
		} else if (*(str1 + i) > *(str2 + i)) {
			return 1;
		}
		i++;
	}
	return 0;
}

// Setam pentru num octeti din memorie valoarea specificata value
void *memset(void *source, int value, size_t num)
{
	char *src = (char *)source;
	char val = (char)value;
	size_t i = 0;
	while (i < num) {
		*(src + i) = val;
		i++;
	}
	return source;
}
