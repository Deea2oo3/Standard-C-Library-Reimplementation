#include <internal/types.h>

struct timespec {
time_t sec;
time_t nano_sec;
};

int nanosleep(const struct timespec *req, struct timespec *rem);
