/* SPDX-License-Identifier: BSD-3-Clause */
#include <internal/types.h>
#ifndef __STDIO_H__
#define __STDIO_H__	1

#ifdef __cplusplus
extern "C" {
#endif

ssize_t puts(const char *str);

#ifdef __cplusplus
}
#endif

#endif
