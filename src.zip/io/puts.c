#include <internal/io.h>
#include <internal/syscall.h>
#include <internal/types.h>
#include <errno.h>
#include <string.h>

ssize_t puts(const char *str)
{
    if (str == NULL) {
        errno = EINVAL;
        return -1;
    }
    int ret = syscall(__NR_write, 1, str, strlen(str));
    if (ret < 0) {
        errno = -ret;
        return -1;
    }
    ret = syscall(__NR_write, 1, "\n", 1);
    return 1;
}
